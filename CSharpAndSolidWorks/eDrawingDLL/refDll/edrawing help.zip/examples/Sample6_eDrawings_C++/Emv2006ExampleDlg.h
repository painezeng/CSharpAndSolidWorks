// Emv2006ExampleDlg.h : header file
//
//{{AFX_INCLUDES()
#include "emodelviewcontrol.h"
//}}AFX_INCLUDES

#if !defined(AFX_EMV2006EXAMPLEDLG_H__56F2918E_01BC_4B02_BE10_EA19FF4E24B1__INCLUDED_)
#define AFX_EMV2006EXAMPLEDLG_H__56F2918E_01BC_4B02_BE10_EA19FF4E24B1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CEmv2006ExampleDlg dialog

class CEmv2006ExampleDlg : public CDialog
{
// Construction
public:
	CEmv2006ExampleDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CEmv2006ExampleDlg)
	enum { IDD = IDD_EMV2006EXAMPLE_DIALOG };
	CEModelViewControl	m_2006Control;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEmv2006ExampleDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CEmv2006ExampleDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnOnComponentSelectionNotifyEmodelviewcontrol1(LPCTSTR ComponentName, long XCoordinate, long YCoordinate);
	afx_msg void OnOnComponentMouseOverNotifyEmodelviewcontrol1(LPCTSTR ComponentName, long XCoordinate, long YCoordinate);
	afx_msg void OnOnFinishedLoadingDocumentEmodelviewcontrol1(LPCTSTR FileName);
	afx_msg void OnOnFinishedSavingDocumentEmodelviewcontrol1();
	afx_msg void OnOpenDoc();
	DECLARE_EVENTSINK_MAP()
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EMV2006EXAMPLEDLG_H__56F2918E_01BC_4B02_BE10_EA19FF4E24B1__INCLUDED_)
