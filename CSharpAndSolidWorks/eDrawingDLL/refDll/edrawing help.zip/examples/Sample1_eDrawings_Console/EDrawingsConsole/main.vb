Option Explicit On
Imports System.Drawing.Printing
Imports System.Drawing


Public Class eDrawingsConsole
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents gb_view As System.Windows.Forms.GroupBox
    Friend WithEvents cb_Explode As System.Windows.Forms.CheckBox
    Friend WithEvents cb_perspective As System.Windows.Forms.CheckBox
    Friend WithEvents gb_Components As System.Windows.Forms.GroupBox
    Friend WithEvents btn_getHidden As System.Windows.Forms.Button
    Friend WithEvents btn_getHighLight As System.Windows.Forms.Button
    Friend WithEvents btn_UnhighlightSelected As System.Windows.Forms.Button
    Friend WithEvents btn_highlightSelected As System.Windows.Forms.Button
    Friend WithEvents btn_HideSelected As System.Windows.Forms.Button
    Friend WithEvents btn_ShowSelected As System.Windows.Forms.Button
    Friend WithEvents lb_Components As System.Windows.Forms.ListBox
    Friend WithEvents btn_Home As System.Windows.Forms.Button
    Friend WithEvents btn_Animate As System.Windows.Forms.Button
    Friend WithEvents btn_top As System.Windows.Forms.Button
    Friend WithEvents btn_left As System.Windows.Forms.Button
    Friend WithEvents btn_front As System.Windows.Forms.Button
    Friend WithEvents Btn_Iso As System.Windows.Forms.Button
    Friend WithEvents gb_FileOp As System.Windows.Forms.GroupBox
    Friend WithEvents btn_SaveAs As System.Windows.Forms.Button
    Friend WithEvents btn_file As System.Windows.Forms.Button
    Friend WithEvents gb_Tooltips As System.Windows.Forms.GroupBox
    Friend WithEvents gb_Events As System.Windows.Forms.GroupBox
    Friend WithEvents cb_MouseOver As System.Windows.Forms.CheckBox
    Friend WithEvents cb_Selection As System.Windows.Forms.CheckBox
    Friend WithEvents gb_Config_sheet As System.Windows.Forms.GroupBox
    Friend WithEvents btn_CreateTT As System.Windows.Forms.Button
    Friend WithEvents Btn_EditTT As System.Windows.Forms.Button
    Friend WithEvents btn_HideSelectedTT As System.Windows.Forms.Button
    Friend WithEvents btn_ShowSelectedTT As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents tb_tt_title As System.Windows.Forms.TextBox
    Friend WithEvents tb_tt_text As System.Windows.Forms.TextBox
    Friend WithEvents nb_ttX As System.Windows.Forms.NumericUpDown
    Friend WithEvents nb_ttY As System.Windows.Forms.NumericUpDown
    Friend WithEvents cb_ShowAtMouse As System.Windows.Forms.CheckBox
    Friend WithEvents lb_ToolTips As System.Windows.Forms.ListBox
    'Friend WithEvents AxEModelViewControl1 As AxEModelView.AxEModelViewControl
    Friend WithEvents btn_rectangle As System.Windows.Forms.Button
    Friend WithEvents btn_Circle As System.Windows.Forms.Button
    Friend WithEvents btn_MarkupText As System.Windows.Forms.Button
    Friend WithEvents btn_CursorRotate As System.Windows.Forms.Button
    Friend WithEvents gb_Markup1 As System.Windows.Forms.GroupBox
    Friend WithEvents btn_Quit As System.Windows.Forms.Button
    Friend WithEvents btn_ShowConfigOrSheet As System.Windows.Forms.Button
    Friend WithEvents btn_Print As System.Windows.Forms.Button
    Friend WithEvents btn_SheetSize As System.Windows.Forms.Button
    Friend WithEvents lb_copies As System.Windows.Forms.Label
    Friend WithEvents lb_printerName As System.Windows.Forms.Label
    Friend WithEvents gb_orientation As System.Windows.Forms.GroupBox
    Friend WithEvents rb_landscape As System.Windows.Forms.RadioButton
    Friend WithEvents rb_portrait As System.Windows.Forms.RadioButton
    Friend WithEvents lb_filename As System.Windows.Forms.Label
    Friend WithEvents cb_color As System.Windows.Forms.CheckBox
    Friend WithEvents cb_Draft As System.Windows.Forms.CheckBox
    Friend WithEvents cb_Shaded As System.Windows.Forms.CheckBox
    Friend WithEvents btn_print_and_ps As System.Windows.Forms.Button
    Friend WithEvents lb_paperSize As System.Windows.Forms.Label
    Friend WithEvents nb_copies As System.Windows.Forms.NumericUpDown
    Friend WithEvents lscale As System.Windows.Forms.GroupBox
    Friend WithEvents btn_showSelMarkup As System.Windows.Forms.Button
    Friend WithEvents lb_markup_id_name As System.Windows.Forms.ListBox
    Friend WithEvents gb_Scale As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents rb_PrintScreen As System.Windows.Forms.RadioButton
    Friend WithEvents rb_100percent As System.Windows.Forms.RadioButton
    Friend WithEvents rb_ScaleToFit As System.Windows.Forms.RadioButton

    Friend WithEvents btn_Close As System.Windows.Forms.Button
    Friend WithEvents cb_PaperSizex As System.Windows.Forms.ComboBox
    Friend WithEvents gb_Markup As System.Windows.Forms.GroupBox
    Friend WithEvents cb_Printers As System.Windows.Forms.ComboBox
    Friend WithEvents tb_docName As System.Windows.Forms.TextBox
    Friend WithEvents lbly As System.Windows.Forms.Label
    Friend WithEvents lblx As System.Windows.Forms.Label
    Friend WithEvents nb_offsetY As System.Windows.Forms.NumericUpDown
    Friend WithEvents nb_offsetx As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents nb_Scale As System.Windows.Forms.NumericUpDown
    Friend WithEvents rb_ScaleBy As System.Windows.Forms.RadioButton
    Friend WithEvents rb_Selection As System.Windows.Forms.RadioButton
    Friend WithEvents lb_sheets_configs As System.Windows.Forms.ListBox
    Friend WithEvents AxEModelViewControl1 As AxEModelView.AxEModelViewControl
    Friend WithEvents lbl_PaperInfo As System.Windows.Forms.Label

    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(eDrawingsConsole))
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog
        Me.gb_view = New System.Windows.Forms.GroupBox
        Me.btn_Home = New System.Windows.Forms.Button
        Me.btn_Animate = New System.Windows.Forms.Button
        Me.btn_top = New System.Windows.Forms.Button
        Me.btn_left = New System.Windows.Forms.Button
        Me.btn_front = New System.Windows.Forms.Button
        Me.Btn_Iso = New System.Windows.Forms.Button
        Me.cb_Explode = New System.Windows.Forms.CheckBox
        Me.cb_perspective = New System.Windows.Forms.CheckBox
        Me.gb_Components = New System.Windows.Forms.GroupBox
        Me.btn_getHidden = New System.Windows.Forms.Button
        Me.btn_getHighLight = New System.Windows.Forms.Button
        Me.btn_UnhighlightSelected = New System.Windows.Forms.Button
        Me.btn_highlightSelected = New System.Windows.Forms.Button
        Me.btn_HideSelected = New System.Windows.Forms.Button
        Me.btn_ShowSelected = New System.Windows.Forms.Button
        Me.lb_Components = New System.Windows.Forms.ListBox
        Me.gb_FileOp = New System.Windows.Forms.GroupBox
        Me.btn_Close = New System.Windows.Forms.Button
        Me.btn_Quit = New System.Windows.Forms.Button
        Me.btn_SaveAs = New System.Windows.Forms.Button
        Me.btn_file = New System.Windows.Forms.Button
        Me.gb_Tooltips = New System.Windows.Forms.GroupBox
        Me.lb_ToolTips = New System.Windows.Forms.ListBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.tb_tt_title = New System.Windows.Forms.TextBox
        Me.tb_tt_text = New System.Windows.Forms.TextBox
        Me.nb_ttX = New System.Windows.Forms.NumericUpDown
        Me.nb_ttY = New System.Windows.Forms.NumericUpDown
        Me.cb_ShowAtMouse = New System.Windows.Forms.CheckBox
        Me.btn_ShowSelectedTT = New System.Windows.Forms.Button
        Me.btn_HideSelectedTT = New System.Windows.Forms.Button
        Me.Btn_EditTT = New System.Windows.Forms.Button
        Me.btn_CreateTT = New System.Windows.Forms.Button
        Me.gb_Events = New System.Windows.Forms.GroupBox
        Me.cb_Selection = New System.Windows.Forms.CheckBox
        Me.cb_MouseOver = New System.Windows.Forms.CheckBox
        Me.gb_Config_sheet = New System.Windows.Forms.GroupBox
        Me.lb_sheets_configs = New System.Windows.Forms.ListBox
        Me.btn_ShowConfigOrSheet = New System.Windows.Forms.Button
        Me.gb_Markup1 = New System.Windows.Forms.GroupBox
        Me.btn_CursorRotate = New System.Windows.Forms.Button
        Me.btn_MarkupText = New System.Windows.Forms.Button
        Me.btn_Circle = New System.Windows.Forms.Button
        Me.btn_rectangle = New System.Windows.Forms.Button
        Me.lscale = New System.Windows.Forms.GroupBox
        Me.gb_Scale = New System.Windows.Forms.GroupBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.nb_Scale = New System.Windows.Forms.NumericUpDown
        Me.lbly = New System.Windows.Forms.Label
        Me.lblx = New System.Windows.Forms.Label
        Me.nb_offsetY = New System.Windows.Forms.NumericUpDown
        Me.nb_offsetx = New System.Windows.Forms.NumericUpDown
        Me.lbl_PaperInfo = New System.Windows.Forms.Label
        Me.cb_Printers = New System.Windows.Forms.ComboBox
        Me.cb_PaperSizex = New System.Windows.Forms.ComboBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.rb_Selection = New System.Windows.Forms.RadioButton
        Me.rb_ScaleBy = New System.Windows.Forms.RadioButton
        Me.rb_PrintScreen = New System.Windows.Forms.RadioButton
        Me.rb_100percent = New System.Windows.Forms.RadioButton
        Me.rb_ScaleToFit = New System.Windows.Forms.RadioButton
        Me.lb_paperSize = New System.Windows.Forms.Label
        Me.lb_copies = New System.Windows.Forms.Label
        Me.lb_printerName = New System.Windows.Forms.Label
        Me.nb_copies = New System.Windows.Forms.NumericUpDown
        Me.gb_orientation = New System.Windows.Forms.GroupBox
        Me.rb_landscape = New System.Windows.Forms.RadioButton
        Me.rb_portrait = New System.Windows.Forms.RadioButton
        Me.lb_filename = New System.Windows.Forms.Label
        Me.cb_color = New System.Windows.Forms.CheckBox
        Me.cb_Draft = New System.Windows.Forms.CheckBox
        Me.cb_Shaded = New System.Windows.Forms.CheckBox
        Me.tb_docName = New System.Windows.Forms.TextBox
        Me.btn_print_and_ps = New System.Windows.Forms.Button
        Me.btn_SheetSize = New System.Windows.Forms.Button
        Me.btn_Print = New System.Windows.Forms.Button
        Me.gb_Markup = New System.Windows.Forms.GroupBox
        Me.btn_showSelMarkup = New System.Windows.Forms.Button
        Me.lb_markup_id_name = New System.Windows.Forms.ListBox
        Me.AxEModelViewControl1 = New AxEModelView.AxEModelViewControl
        Me.gb_view.SuspendLayout()
        Me.gb_Components.SuspendLayout()
        Me.gb_FileOp.SuspendLayout()
        Me.gb_Tooltips.SuspendLayout()
        CType(Me.nb_ttX, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nb_ttY, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gb_Events.SuspendLayout()
        Me.gb_Config_sheet.SuspendLayout()
        Me.gb_Markup1.SuspendLayout()
        Me.lscale.SuspendLayout()
        Me.gb_Scale.SuspendLayout()
        CType(Me.nb_Scale, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nb_offsetY, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nb_offsetx, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.nb_copies, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gb_orientation.SuspendLayout()
        Me.gb_Markup.SuspendLayout()
        CType(Me.AxEModelViewControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.Filter = "EDrawing(*.edrw;*.eprt;*.easm)|*.edrw;*.eprt;*.easm|SolidWorks(*.slddrw;*.sldprt;" & _
            "*.sldasm)|*.slddrw;*.sldprt;*.sldasm|AutoCad(*.dwg;*.dxf)|*.dwg;*.dxf"
        '
        'gb_view
        '
        Me.gb_view.Controls.Add(Me.btn_Home)
        Me.gb_view.Controls.Add(Me.btn_Animate)
        Me.gb_view.Controls.Add(Me.btn_top)
        Me.gb_view.Controls.Add(Me.btn_left)
        Me.gb_view.Controls.Add(Me.btn_front)
        Me.gb_view.Controls.Add(Me.Btn_Iso)
        Me.gb_view.Controls.Add(Me.cb_Explode)
        Me.gb_view.Controls.Add(Me.cb_perspective)
        Me.gb_view.Enabled = False
        Me.gb_view.Location = New System.Drawing.Point(560, 160)
        Me.gb_view.Name = "gb_view"
        Me.gb_view.Size = New System.Drawing.Size(104, 264)
        Me.gb_view.TabIndex = 24
        Me.gb_view.TabStop = False
        Me.gb_view.Text = "Viewing Options"
        '
        'btn_Home
        '
        Me.btn_Home.Enabled = False
        Me.btn_Home.Location = New System.Drawing.Point(8, 160)
        Me.btn_Home.Name = "btn_Home"
        Me.btn_Home.Size = New System.Drawing.Size(80, 24)
        Me.btn_Home.TabIndex = 29
        Me.btn_Home.Text = "Home"
        '
        'btn_Animate
        '
        Me.btn_Animate.Enabled = False
        Me.btn_Animate.Location = New System.Drawing.Point(8, 184)
        Me.btn_Animate.Name = "btn_Animate"
        Me.btn_Animate.Size = New System.Drawing.Size(80, 24)
        Me.btn_Animate.TabIndex = 28
        Me.btn_Animate.Text = "Animate"
        '
        'btn_top
        '
        Me.btn_top.Enabled = False
        Me.btn_top.Location = New System.Drawing.Point(8, 136)
        Me.btn_top.Name = "btn_top"
        Me.btn_top.Size = New System.Drawing.Size(80, 24)
        Me.btn_top.TabIndex = 27
        Me.btn_top.Text = "Top"
        '
        'btn_left
        '
        Me.btn_left.Enabled = False
        Me.btn_left.Location = New System.Drawing.Point(8, 112)
        Me.btn_left.Name = "btn_left"
        Me.btn_left.Size = New System.Drawing.Size(80, 24)
        Me.btn_left.TabIndex = 26
        Me.btn_left.Text = "Left"
        '
        'btn_front
        '
        Me.btn_front.Enabled = False
        Me.btn_front.Location = New System.Drawing.Point(8, 88)
        Me.btn_front.Name = "btn_front"
        Me.btn_front.Size = New System.Drawing.Size(80, 24)
        Me.btn_front.TabIndex = 25
        Me.btn_front.Text = "Front"
        '
        'Btn_Iso
        '
        Me.Btn_Iso.Enabled = False
        Me.Btn_Iso.Location = New System.Drawing.Point(8, 64)
        Me.Btn_Iso.Name = "Btn_Iso"
        Me.Btn_Iso.Size = New System.Drawing.Size(80, 24)
        Me.Btn_Iso.TabIndex = 24
        Me.Btn_Iso.Text = "Isometric"
        '
        'cb_Explode
        '
        Me.cb_Explode.Enabled = False
        Me.cb_Explode.Location = New System.Drawing.Point(8, 240)
        Me.cb_Explode.Name = "cb_Explode"
        Me.cb_Explode.Size = New System.Drawing.Size(64, 16)
        Me.cb_Explode.TabIndex = 23
        Me.cb_Explode.Text = "Explode"
        '
        'cb_perspective
        '
        Me.cb_perspective.Enabled = False
        Me.cb_perspective.Location = New System.Drawing.Point(8, 216)
        Me.cb_perspective.Name = "cb_perspective"
        Me.cb_perspective.Size = New System.Drawing.Size(88, 16)
        Me.cb_perspective.TabIndex = 22
        Me.cb_perspective.Text = "Perspective"
        '
        'gb_Components
        '
        Me.gb_Components.Controls.Add(Me.btn_getHidden)
        Me.gb_Components.Controls.Add(Me.btn_getHighLight)
        Me.gb_Components.Controls.Add(Me.btn_UnhighlightSelected)
        Me.gb_Components.Controls.Add(Me.btn_highlightSelected)
        Me.gb_Components.Controls.Add(Me.btn_HideSelected)
        Me.gb_Components.Controls.Add(Me.btn_ShowSelected)
        Me.gb_Components.Controls.Add(Me.lb_Components)
        Me.gb_Components.Enabled = False
        Me.gb_Components.Location = New System.Drawing.Point(8, 432)
        Me.gb_Components.Name = "gb_Components"
        Me.gb_Components.Size = New System.Drawing.Size(656, 140)
        Me.gb_Components.TabIndex = 25
        Me.gb_Components.TabStop = False
        Me.gb_Components.Text = "Components"
        '
        'btn_getHidden
        '
        Me.btn_getHidden.Enabled = False
        Me.btn_getHidden.Location = New System.Drawing.Point(200, 19)
        Me.btn_getHidden.Name = "btn_getHidden"
        Me.btn_getHidden.Size = New System.Drawing.Size(104, 56)
        Me.btn_getHidden.TabIndex = 31
        Me.btn_getHidden.Text = "Get Hidden State of selected list item"
        '
        'btn_getHighLight
        '
        Me.btn_getHighLight.Enabled = False
        Me.btn_getHighLight.Location = New System.Drawing.Point(200, 81)
        Me.btn_getHighLight.Name = "btn_getHighLight"
        Me.btn_getHighLight.Size = New System.Drawing.Size(104, 56)
        Me.btn_getHighLight.TabIndex = 30
        Me.btn_getHighLight.Text = "Get Highlight State of selected list item"
        '
        'btn_UnhighlightSelected
        '
        Me.btn_UnhighlightSelected.Enabled = False
        Me.btn_UnhighlightSelected.Location = New System.Drawing.Point(8, 114)
        Me.btn_UnhighlightSelected.Name = "btn_UnhighlightSelected"
        Me.btn_UnhighlightSelected.Size = New System.Drawing.Size(168, 24)
        Me.btn_UnhighlightSelected.TabIndex = 29
        Me.btn_UnhighlightSelected.Text = "Unhighlight selected list item"
        '
        'btn_highlightSelected
        '
        Me.btn_highlightSelected.Enabled = False
        Me.btn_highlightSelected.Location = New System.Drawing.Point(8, 84)
        Me.btn_highlightSelected.Name = "btn_highlightSelected"
        Me.btn_highlightSelected.Size = New System.Drawing.Size(168, 24)
        Me.btn_highlightSelected.TabIndex = 28
        Me.btn_highlightSelected.Text = "Highlight selected list item"
        '
        'btn_HideSelected
        '
        Me.btn_HideSelected.Enabled = False
        Me.btn_HideSelected.Location = New System.Drawing.Point(8, 24)
        Me.btn_HideSelected.Name = "btn_HideSelected"
        Me.btn_HideSelected.Size = New System.Drawing.Size(168, 24)
        Me.btn_HideSelected.TabIndex = 27
        Me.btn_HideSelected.Text = "Hide selected list item"
        '
        'btn_ShowSelected
        '
        Me.btn_ShowSelected.Enabled = False
        Me.btn_ShowSelected.Location = New System.Drawing.Point(8, 54)
        Me.btn_ShowSelected.Name = "btn_ShowSelected"
        Me.btn_ShowSelected.Size = New System.Drawing.Size(168, 24)
        Me.btn_ShowSelected.TabIndex = 26
        Me.btn_ShowSelected.Text = "Show selected list item"
        '
        'lb_Components
        '
        Me.lb_Components.Location = New System.Drawing.Point(312, 24)
        Me.lb_Components.Name = "lb_Components"
        Me.lb_Components.Size = New System.Drawing.Size(336, 108)
        Me.lb_Components.TabIndex = 24
        '
        'gb_FileOp
        '
        Me.gb_FileOp.Controls.Add(Me.btn_Close)
        Me.gb_FileOp.Controls.Add(Me.btn_Quit)
        Me.gb_FileOp.Controls.Add(Me.btn_SaveAs)
        Me.gb_FileOp.Controls.Add(Me.btn_file)
        Me.gb_FileOp.Location = New System.Drawing.Point(560, 16)
        Me.gb_FileOp.Name = "gb_FileOp"
        Me.gb_FileOp.Size = New System.Drawing.Size(104, 144)
        Me.gb_FileOp.TabIndex = 26
        Me.gb_FileOp.TabStop = False
        Me.gb_FileOp.Text = "File Operations"
        '
        'btn_Close
        '
        Me.btn_Close.Location = New System.Drawing.Point(8, 48)
        Me.btn_Close.Name = "btn_Close"
        Me.btn_Close.Size = New System.Drawing.Size(80, 24)
        Me.btn_Close.TabIndex = 13
        Me.btn_Close.Text = "Close"
        '
        'btn_Quit
        '
        Me.btn_Quit.Location = New System.Drawing.Point(8, 96)
        Me.btn_Quit.Name = "btn_Quit"
        Me.btn_Quit.Size = New System.Drawing.Size(80, 24)
        Me.btn_Quit.TabIndex = 12
        Me.btn_Quit.Text = "Quit"
        '
        'btn_SaveAs
        '
        Me.btn_SaveAs.Enabled = False
        Me.btn_SaveAs.Location = New System.Drawing.Point(8, 72)
        Me.btn_SaveAs.Name = "btn_SaveAs"
        Me.btn_SaveAs.Size = New System.Drawing.Size(80, 24)
        Me.btn_SaveAs.TabIndex = 11
        Me.btn_SaveAs.Text = "Save As..."
        '
        'btn_file
        '
        Me.btn_file.Location = New System.Drawing.Point(8, 24)
        Me.btn_file.Name = "btn_file"
        Me.btn_file.Size = New System.Drawing.Size(80, 24)
        Me.btn_file.TabIndex = 9
        Me.btn_file.Text = "Open File..."
        '
        'gb_Tooltips
        '
        Me.gb_Tooltips.Controls.Add(Me.lb_ToolTips)
        Me.gb_Tooltips.Controls.Add(Me.Label4)
        Me.gb_Tooltips.Controls.Add(Me.Label3)
        Me.gb_Tooltips.Controls.Add(Me.Label2)
        Me.gb_Tooltips.Controls.Add(Me.Label1)
        Me.gb_Tooltips.Controls.Add(Me.tb_tt_title)
        Me.gb_Tooltips.Controls.Add(Me.tb_tt_text)
        Me.gb_Tooltips.Controls.Add(Me.nb_ttX)
        Me.gb_Tooltips.Controls.Add(Me.nb_ttY)
        Me.gb_Tooltips.Controls.Add(Me.cb_ShowAtMouse)
        Me.gb_Tooltips.Controls.Add(Me.btn_ShowSelectedTT)
        Me.gb_Tooltips.Controls.Add(Me.btn_HideSelectedTT)
        Me.gb_Tooltips.Controls.Add(Me.Btn_EditTT)
        Me.gb_Tooltips.Controls.Add(Me.btn_CreateTT)
        Me.gb_Tooltips.Enabled = False
        Me.gb_Tooltips.Location = New System.Drawing.Point(672, 16)
        Me.gb_Tooltips.Name = "gb_Tooltips"
        Me.gb_Tooltips.Size = New System.Drawing.Size(184, 256)
        Me.gb_Tooltips.TabIndex = 27
        Me.gb_Tooltips.TabStop = False
        Me.gb_Tooltips.Text = "Tooltips"
        '
        'lb_ToolTips
        '
        Me.lb_ToolTips.Enabled = False
        Me.lb_ToolTips.Location = New System.Drawing.Point(8, 16)
        Me.lb_ToolTips.Name = "lb_ToolTips"
        Me.lb_ToolTips.Size = New System.Drawing.Size(32, 95)
        Me.lb_ToolTips.TabIndex = 32
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(16, 200)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(24, 24)
        Me.Label4.TabIndex = 31
        Me.Label4.Text = "Y:"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(16, 176)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(24, 16)
        Me.Label3.TabIndex = 30
        Me.Label3.Text = "X"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(8, 152)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(32, 16)
        Me.Label2.TabIndex = 29
        Me.Label2.Text = "Text"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 128)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(32, 16)
        Me.Label1.TabIndex = 28
        Me.Label1.Text = "Title"
        '
        'tb_tt_title
        '
        Me.tb_tt_title.Location = New System.Drawing.Point(40, 128)
        Me.tb_tt_title.Name = "tb_tt_title"
        Me.tb_tt_title.Size = New System.Drawing.Size(120, 20)
        Me.tb_tt_title.TabIndex = 27
        Me.tb_tt_title.Text = "ToolTip Title"
        '
        'tb_tt_text
        '
        Me.tb_tt_text.Location = New System.Drawing.Point(40, 152)
        Me.tb_tt_text.Name = "tb_tt_text"
        Me.tb_tt_text.Size = New System.Drawing.Size(120, 20)
        Me.tb_tt_text.TabIndex = 26
        Me.tb_tt_text.Text = "ToolTip Text"
        '
        'nb_ttX
        '
        Me.nb_ttX.Location = New System.Drawing.Point(40, 176)
        Me.nb_ttX.Maximum = New Decimal(New Integer() {300, 0, 0, 0})
        Me.nb_ttX.Name = "nb_ttX"
        Me.nb_ttX.Size = New System.Drawing.Size(120, 20)
        Me.nb_ttX.TabIndex = 25
        '
        'nb_ttY
        '
        Me.nb_ttY.Location = New System.Drawing.Point(40, 200)
        Me.nb_ttY.Maximum = New Decimal(New Integer() {300, 0, 0, 0})
        Me.nb_ttY.Name = "nb_ttY"
        Me.nb_ttY.Size = New System.Drawing.Size(120, 20)
        Me.nb_ttY.TabIndex = 24
        '
        'cb_ShowAtMouse
        '
        Me.cb_ShowAtMouse.Location = New System.Drawing.Point(24, 224)
        Me.cb_ShowAtMouse.Name = "cb_ShowAtMouse"
        Me.cb_ShowAtMouse.Size = New System.Drawing.Size(152, 24)
        Me.cb_ShowAtMouse.TabIndex = 23
        Me.cb_ShowAtMouse.Text = "Show at Mouse Position?"
        '
        'btn_ShowSelectedTT
        '
        Me.btn_ShowSelectedTT.Enabled = False
        Me.btn_ShowSelectedTT.Location = New System.Drawing.Point(48, 64)
        Me.btn_ShowSelectedTT.Name = "btn_ShowSelectedTT"
        Me.btn_ShowSelectedTT.Size = New System.Drawing.Size(112, 24)
        Me.btn_ShowSelectedTT.TabIndex = 20
        Me.btn_ShowSelectedTT.Text = "Show Tooltip"
        '
        'btn_HideSelectedTT
        '
        Me.btn_HideSelectedTT.Enabled = False
        Me.btn_HideSelectedTT.Location = New System.Drawing.Point(48, 40)
        Me.btn_HideSelectedTT.Name = "btn_HideSelectedTT"
        Me.btn_HideSelectedTT.Size = New System.Drawing.Size(112, 24)
        Me.btn_HideSelectedTT.TabIndex = 19
        Me.btn_HideSelectedTT.Text = "Hide Tooltip"
        '
        'Btn_EditTT
        '
        Me.Btn_EditTT.Enabled = False
        Me.Btn_EditTT.Location = New System.Drawing.Point(48, 88)
        Me.Btn_EditTT.Name = "Btn_EditTT"
        Me.Btn_EditTT.Size = New System.Drawing.Size(112, 24)
        Me.Btn_EditTT.TabIndex = 18
        Me.Btn_EditTT.Text = "Edit Tooltip"
        '
        'btn_CreateTT
        '
        Me.btn_CreateTT.Enabled = False
        Me.btn_CreateTT.Location = New System.Drawing.Point(48, 16)
        Me.btn_CreateTT.Name = "btn_CreateTT"
        Me.btn_CreateTT.Size = New System.Drawing.Size(112, 24)
        Me.btn_CreateTT.TabIndex = 17
        Me.btn_CreateTT.Text = "Create ToolTip"
        '
        'gb_Events
        '
        Me.gb_Events.Controls.Add(Me.cb_Selection)
        Me.gb_Events.Controls.Add(Me.cb_MouseOver)
        Me.gb_Events.Enabled = False
        Me.gb_Events.Location = New System.Drawing.Point(672, 432)
        Me.gb_Events.Name = "gb_Events"
        Me.gb_Events.Size = New System.Drawing.Size(184, 152)
        Me.gb_Events.TabIndex = 28
        Me.gb_Events.TabStop = False
        Me.gb_Events.Text = "Events"
        '
        'cb_Selection
        '
        Me.cb_Selection.Enabled = False
        Me.cb_Selection.Location = New System.Drawing.Point(16, 48)
        Me.cb_Selection.Name = "cb_Selection"
        Me.cb_Selection.Size = New System.Drawing.Size(152, 16)
        Me.cb_Selection.TabIndex = 1
        Me.cb_Selection.Text = "Track Select Component"
        '
        'cb_MouseOver
        '
        Me.cb_MouseOver.Enabled = False
        Me.cb_MouseOver.Location = New System.Drawing.Point(16, 24)
        Me.cb_MouseOver.Name = "cb_MouseOver"
        Me.cb_MouseOver.Size = New System.Drawing.Size(120, 16)
        Me.cb_MouseOver.TabIndex = 0
        Me.cb_MouseOver.Text = "Track Mouse-Over Component"
        '
        'gb_Config_sheet
        '
        Me.gb_Config_sheet.Controls.Add(Me.lb_sheets_configs)
        Me.gb_Config_sheet.Controls.Add(Me.btn_ShowConfigOrSheet)
        Me.gb_Config_sheet.Enabled = False
        Me.gb_Config_sheet.Location = New System.Drawing.Point(16, 272)
        Me.gb_Config_sheet.Name = "gb_Config_sheet"
        Me.gb_Config_sheet.Size = New System.Drawing.Size(536, 152)
        Me.gb_Config_sheet.TabIndex = 29
        Me.gb_Config_sheet.TabStop = False
        Me.gb_Config_sheet.Text = "Sheets and Configurations"
        '
        'lb_sheets_configs
        '
        Me.lb_sheets_configs.FormattingEnabled = True
        Me.lb_sheets_configs.Location = New System.Drawing.Point(16, 24)
        Me.lb_sheets_configs.Name = "lb_sheets_configs"
        Me.lb_sheets_configs.Size = New System.Drawing.Size(504, 95)
        Me.lb_sheets_configs.TabIndex = 2
        '
        'btn_ShowConfigOrSheet
        '
        Me.btn_ShowConfigOrSheet.Location = New System.Drawing.Point(16, 120)
        Me.btn_ShowConfigOrSheet.Name = "btn_ShowConfigOrSheet"
        Me.btn_ShowConfigOrSheet.Size = New System.Drawing.Size(504, 24)
        Me.btn_ShowConfigOrSheet.TabIndex = 1
        '
        'gb_Markup1
        '
        Me.gb_Markup1.Controls.Add(Me.btn_CursorRotate)
        Me.gb_Markup1.Controls.Add(Me.btn_MarkupText)
        Me.gb_Markup1.Controls.Add(Me.btn_Circle)
        Me.gb_Markup1.Controls.Add(Me.btn_rectangle)
        Me.gb_Markup1.Enabled = False
        Me.gb_Markup1.Location = New System.Drawing.Point(672, 272)
        Me.gb_Markup1.Name = "gb_Markup1"
        Me.gb_Markup1.Size = New System.Drawing.Size(184, 152)
        Me.gb_Markup1.TabIndex = 31
        Me.gb_Markup1.TabStop = False
        Me.gb_Markup1.Text = "Cursor"
        '
        'btn_CursorRotate
        '
        Me.btn_CursorRotate.Enabled = False
        Me.btn_CursorRotate.Location = New System.Drawing.Point(16, 96)
        Me.btn_CursorRotate.Name = "btn_CursorRotate"
        Me.btn_CursorRotate.Size = New System.Drawing.Size(152, 24)
        Me.btn_CursorRotate.TabIndex = 3
        Me.btn_CursorRotate.Text = "Rotate"
        '
        'btn_MarkupText
        '
        Me.btn_MarkupText.Enabled = False
        Me.btn_MarkupText.Location = New System.Drawing.Point(16, 72)
        Me.btn_MarkupText.Name = "btn_MarkupText"
        Me.btn_MarkupText.Size = New System.Drawing.Size(152, 24)
        Me.btn_MarkupText.TabIndex = 2
        Me.btn_MarkupText.Text = "Text"
        '
        'btn_Circle
        '
        Me.btn_Circle.Enabled = False
        Me.btn_Circle.Location = New System.Drawing.Point(16, 48)
        Me.btn_Circle.Name = "btn_Circle"
        Me.btn_Circle.Size = New System.Drawing.Size(152, 24)
        Me.btn_Circle.TabIndex = 1
        Me.btn_Circle.Text = "Circle"
        '
        'btn_rectangle
        '
        Me.btn_rectangle.Enabled = False
        Me.btn_rectangle.Location = New System.Drawing.Point(16, 24)
        Me.btn_rectangle.Name = "btn_rectangle"
        Me.btn_rectangle.Size = New System.Drawing.Size(152, 24)
        Me.btn_rectangle.TabIndex = 0
        Me.btn_rectangle.Text = "Rectangle"
        '
        'lscale
        '
        Me.lscale.Controls.Add(Me.gb_Scale)
        Me.lscale.Controls.Add(Me.btn_SheetSize)
        Me.lscale.Controls.Add(Me.btn_Print)
        Me.lscale.Enabled = False
        Me.lscale.Location = New System.Drawing.Point(32, 576)
        Me.lscale.Name = "lscale"
        Me.lscale.Size = New System.Drawing.Size(592, 288)
        Me.lscale.TabIndex = 54
        Me.lscale.TabStop = False
        Me.lscale.Text = "Print"
        '
        'gb_Scale
        '
        Me.gb_Scale.Controls.Add(Me.Label5)
        Me.gb_Scale.Controls.Add(Me.nb_Scale)
        Me.gb_Scale.Controls.Add(Me.lbly)
        Me.gb_Scale.Controls.Add(Me.lblx)
        Me.gb_Scale.Controls.Add(Me.nb_offsetY)
        Me.gb_Scale.Controls.Add(Me.nb_offsetx)
        Me.gb_Scale.Controls.Add(Me.lbl_PaperInfo)
        Me.gb_Scale.Controls.Add(Me.cb_Printers)
        Me.gb_Scale.Controls.Add(Me.cb_PaperSizex)
        Me.gb_Scale.Controls.Add(Me.GroupBox1)
        Me.gb_Scale.Controls.Add(Me.lb_paperSize)
        Me.gb_Scale.Controls.Add(Me.lb_copies)
        Me.gb_Scale.Controls.Add(Me.lb_printerName)
        Me.gb_Scale.Controls.Add(Me.nb_copies)
        Me.gb_Scale.Controls.Add(Me.gb_orientation)
        Me.gb_Scale.Controls.Add(Me.lb_filename)
        Me.gb_Scale.Controls.Add(Me.cb_color)
        Me.gb_Scale.Controls.Add(Me.cb_Draft)
        Me.gb_Scale.Controls.Add(Me.cb_Shaded)
        Me.gb_Scale.Controls.Add(Me.tb_docName)
        Me.gb_Scale.Controls.Add(Me.btn_print_and_ps)
        Me.gb_Scale.Location = New System.Drawing.Point(8, 33)
        Me.gb_Scale.Name = "gb_Scale"
        Me.gb_Scale.Size = New System.Drawing.Size(552, 248)
        Me.gb_Scale.TabIndex = 74
        Me.gb_Scale.TabStop = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(386, 207)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(34, 13)
        Me.Label5.TabIndex = 104
        Me.Label5.Text = "Scale"
        '
        'nb_Scale
        '
        Me.nb_Scale.DecimalPlaces = 1
        Me.nb_Scale.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.nb_Scale.Location = New System.Drawing.Point(426, 200)
        Me.nb_Scale.Maximum = New Decimal(New Integer() {2, 0, 0, 0})
        Me.nb_Scale.Minimum = New Decimal(New Integer() {1, 0, 0, 262144})
        Me.nb_Scale.Name = "nb_Scale"
        Me.nb_Scale.Size = New System.Drawing.Size(120, 20)
        Me.nb_Scale.TabIndex = 103
        Me.nb_Scale.Value = New Decimal(New Integer() {1, 0, 0, 262144})
        '
        'lbly
        '
        Me.lbly.AutoSize = True
        Me.lbly.Location = New System.Drawing.Point(211, 207)
        Me.lbly.Name = "lbly"
        Me.lbly.Size = New System.Drawing.Size(45, 13)
        Me.lbly.TabIndex = 102
        Me.lbly.Text = "Offset Y"
        '
        'lblx
        '
        Me.lblx.AutoSize = True
        Me.lblx.Location = New System.Drawing.Point(29, 207)
        Me.lblx.Name = "lblx"
        Me.lblx.Size = New System.Drawing.Size(45, 13)
        Me.lblx.TabIndex = 101
        Me.lblx.Text = "Offset X"
        '
        'nb_offsetY
        '
        Me.nb_offsetY.Location = New System.Drawing.Point(271, 200)
        Me.nb_offsetY.Maximum = New Decimal(New Integer() {20000, 0, 0, 0})
        Me.nb_offsetY.Name = "nb_offsetY"
        Me.nb_offsetY.Size = New System.Drawing.Size(109, 20)
        Me.nb_offsetY.TabIndex = 100
        '
        'nb_offsetx
        '
        Me.nb_offsetx.Location = New System.Drawing.Point(80, 200)
        Me.nb_offsetx.Maximum = New Decimal(New Integer() {20000, 0, 0, 0})
        Me.nb_offsetx.Name = "nb_offsetx"
        Me.nb_offsetx.Size = New System.Drawing.Size(117, 20)
        Me.nb_offsetx.TabIndex = 99
        '
        'lbl_PaperInfo
        '
        Me.lbl_PaperInfo.Location = New System.Drawing.Point(24, 168)
        Me.lbl_PaperInfo.Name = "lbl_PaperInfo"
        Me.lbl_PaperInfo.Size = New System.Drawing.Size(512, 23)
        Me.lbl_PaperInfo.TabIndex = 98
        '
        'cb_Printers
        '
        Me.cb_Printers.Location = New System.Drawing.Point(104, 72)
        Me.cb_Printers.Name = "cb_Printers"
        Me.cb_Printers.Size = New System.Drawing.Size(256, 21)
        Me.cb_Printers.TabIndex = 97
        '
        'cb_PaperSizex
        '
        Me.cb_PaperSizex.Location = New System.Drawing.Point(448, 133)
        Me.cb_PaperSizex.Name = "cb_PaperSizex"
        Me.cb_PaperSizex.Size = New System.Drawing.Size(88, 21)
        Me.cb_PaperSizex.TabIndex = 96
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rb_Selection)
        Me.GroupBox1.Controls.Add(Me.rb_ScaleBy)
        Me.GroupBox1.Controls.Add(Me.rb_PrintScreen)
        Me.GroupBox1.Controls.Add(Me.rb_100percent)
        Me.GroupBox1.Controls.Add(Me.rb_ScaleToFit)
        Me.GroupBox1.Location = New System.Drawing.Point(426, 7)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(120, 120)
        Me.GroupBox1.TabIndex = 95
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Scale"
        '
        'rb_Selection
        '
        Me.rb_Selection.AutoSize = True
        Me.rb_Selection.Location = New System.Drawing.Point(8, 97)
        Me.rb_Selection.Name = "rb_Selection"
        Me.rb_Selection.Size = New System.Drawing.Size(69, 17)
        Me.rb_Selection.TabIndex = 99
        Me.rb_Selection.TabStop = True
        Me.rb_Selection.Text = "Selection"
        Me.rb_Selection.UseVisualStyleBackColor = True
        '
        'rb_ScaleBy
        '
        Me.rb_ScaleBy.AutoSize = True
        Me.rb_ScaleBy.Location = New System.Drawing.Point(8, 76)
        Me.rb_ScaleBy.Name = "rb_ScaleBy"
        Me.rb_ScaleBy.Size = New System.Drawing.Size(75, 17)
        Me.rb_ScaleBy.TabIndex = 98
        Me.rb_ScaleBy.TabStop = True
        Me.rb_ScaleBy.Text = "Scale by..."
        Me.rb_ScaleBy.UseVisualStyleBackColor = True
        '
        'rb_PrintScreen
        '
        Me.rb_PrintScreen.Location = New System.Drawing.Point(8, 57)
        Me.rb_PrintScreen.Name = "rb_PrintScreen"
        Me.rb_PrintScreen.Size = New System.Drawing.Size(96, 16)
        Me.rb_PrintScreen.TabIndex = 97
        Me.rb_PrintScreen.Text = "Print Screen"
        '
        'rb_100percent
        '
        Me.rb_100percent.Checked = True
        Me.rb_100percent.Location = New System.Drawing.Point(8, 36)
        Me.rb_100percent.Name = "rb_100percent"
        Me.rb_100percent.Size = New System.Drawing.Size(96, 16)
        Me.rb_100percent.TabIndex = 96
        Me.rb_100percent.TabStop = True
        Me.rb_100percent.Text = "100%"
        '
        'rb_ScaleToFit
        '
        Me.rb_ScaleToFit.Location = New System.Drawing.Point(8, 16)
        Me.rb_ScaleToFit.Name = "rb_ScaleToFit"
        Me.rb_ScaleToFit.Size = New System.Drawing.Size(96, 16)
        Me.rb_ScaleToFit.TabIndex = 95
        Me.rb_ScaleToFit.Text = "Scale To Fit"
        '
        'lb_paperSize
        '
        Me.lb_paperSize.Location = New System.Drawing.Point(378, 136)
        Me.lb_paperSize.Name = "lb_paperSize"
        Me.lb_paperSize.Size = New System.Drawing.Size(64, 16)
        Me.lb_paperSize.TabIndex = 88
        Me.lb_paperSize.Text = "Paper Size"
        '
        'lb_copies
        '
        Me.lb_copies.Location = New System.Drawing.Point(272, 136)
        Me.lb_copies.Name = "lb_copies"
        Me.lb_copies.Size = New System.Drawing.Size(40, 16)
        Me.lb_copies.TabIndex = 87
        Me.lb_copies.Text = "Copies"
        '
        'lb_printerName
        '
        Me.lb_printerName.Location = New System.Drawing.Point(8, 72)
        Me.lb_printerName.Name = "lb_printerName"
        Me.lb_printerName.Size = New System.Drawing.Size(72, 16)
        Me.lb_printerName.TabIndex = 85
        Me.lb_printerName.Text = "Printer Name"
        '
        'nb_copies
        '
        Me.nb_copies.Location = New System.Drawing.Point(320, 136)
        Me.nb_copies.Maximum = New Decimal(New Integer() {99, 0, 0, 0})
        Me.nb_copies.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nb_copies.Name = "nb_copies"
        Me.nb_copies.Size = New System.Drawing.Size(40, 20)
        Me.nb_copies.TabIndex = 83
        Me.nb_copies.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'gb_orientation
        '
        Me.gb_orientation.Controls.Add(Me.rb_landscape)
        Me.gb_orientation.Controls.Add(Me.rb_portrait)
        Me.gb_orientation.Location = New System.Drawing.Point(80, 120)
        Me.gb_orientation.Name = "gb_orientation"
        Me.gb_orientation.Size = New System.Drawing.Size(176, 40)
        Me.gb_orientation.TabIndex = 82
        Me.gb_orientation.TabStop = False
        Me.gb_orientation.Text = "Orientation"
        '
        'rb_landscape
        '
        Me.rb_landscape.Location = New System.Drawing.Point(88, 16)
        Me.rb_landscape.Name = "rb_landscape"
        Me.rb_landscape.Size = New System.Drawing.Size(80, 16)
        Me.rb_landscape.TabIndex = 1
        Me.rb_landscape.Text = "Landscape"
        '
        'rb_portrait
        '
        Me.rb_portrait.Checked = True
        Me.rb_portrait.Location = New System.Drawing.Point(16, 16)
        Me.rb_portrait.Name = "rb_portrait"
        Me.rb_portrait.Size = New System.Drawing.Size(64, 16)
        Me.rb_portrait.TabIndex = 0
        Me.rb_portrait.TabStop = True
        Me.rb_portrait.Text = "Portrait"
        '
        'lb_filename
        '
        Me.lb_filename.Location = New System.Drawing.Point(8, 48)
        Me.lb_filename.Name = "lb_filename"
        Me.lb_filename.Size = New System.Drawing.Size(88, 24)
        Me.lb_filename.TabIndex = 80
        Me.lb_filename.Text = "Print Job Name"
        '
        'cb_color
        '
        Me.cb_color.Location = New System.Drawing.Point(16, 144)
        Me.cb_color.Name = "cb_color"
        Me.cb_color.Size = New System.Drawing.Size(56, 16)
        Me.cb_color.TabIndex = 78
        Me.cb_color.Text = "Color"
        '
        'cb_Draft
        '
        Me.cb_Draft.Location = New System.Drawing.Point(16, 120)
        Me.cb_Draft.Name = "cb_Draft"
        Me.cb_Draft.Size = New System.Drawing.Size(48, 16)
        Me.cb_Draft.TabIndex = 77
        Me.cb_Draft.Text = "Draft"
        '
        'cb_Shaded
        '
        Me.cb_Shaded.Location = New System.Drawing.Point(16, 96)
        Me.cb_Shaded.Name = "cb_Shaded"
        Me.cb_Shaded.Size = New System.Drawing.Size(64, 16)
        Me.cb_Shaded.TabIndex = 76
        Me.cb_Shaded.Text = "Shaded"
        '
        'tb_docName
        '
        Me.tb_docName.Location = New System.Drawing.Point(104, 48)
        Me.tb_docName.Name = "tb_docName"
        Me.tb_docName.Size = New System.Drawing.Size(256, 20)
        Me.tb_docName.TabIndex = 75
        Me.tb_docName.Text = "My Print Job"
        '
        'btn_print_and_ps
        '
        Me.btn_print_and_ps.Enabled = False
        Me.btn_print_and_ps.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_print_and_ps.ForeColor = System.Drawing.SystemColors.MenuText
        Me.btn_print_and_ps.Location = New System.Drawing.Point(16, 16)
        Me.btn_print_and_ps.Name = "btn_print_and_ps"
        Me.btn_print_and_ps.Size = New System.Drawing.Size(152, 24)
        Me.btn_print_and_ps.TabIndex = 74
        Me.btn_print_and_ps.Text = "Print with API options"
        '
        'btn_SheetSize
        '
        Me.btn_SheetSize.Enabled = False
        Me.btn_SheetSize.Location = New System.Drawing.Point(222, 10)
        Me.btn_SheetSize.Name = "btn_SheetSize"
        Me.btn_SheetSize.Size = New System.Drawing.Size(128, 24)
        Me.btn_SheetSize.TabIndex = 60
        Me.btn_SheetSize.Text = "Query Sheet Size"
        '
        'btn_Print
        '
        Me.btn_Print.Enabled = False
        Me.btn_Print.Location = New System.Drawing.Point(64, 10)
        Me.btn_Print.Name = "btn_Print"
        Me.btn_Print.Size = New System.Drawing.Size(152, 24)
        Me.btn_Print.TabIndex = 57
        Me.btn_Print.Text = "Print with Standard Dialog..."
        '
        'gb_Markup
        '
        Me.gb_Markup.Controls.Add(Me.btn_showSelMarkup)
        Me.gb_Markup.Controls.Add(Me.lb_markup_id_name)
        Me.gb_Markup.Enabled = False
        Me.gb_Markup.Location = New System.Drawing.Point(640, 592)
        Me.gb_Markup.Name = "gb_Markup"
        Me.gb_Markup.Size = New System.Drawing.Size(216, 272)
        Me.gb_Markup.TabIndex = 56
        Me.gb_Markup.TabStop = False
        Me.gb_Markup.Text = "Markup"
        '
        'btn_showSelMarkup
        '
        Me.btn_showSelMarkup.Enabled = False
        Me.btn_showSelMarkup.Location = New System.Drawing.Point(8, 232)
        Me.btn_showSelMarkup.Name = "btn_showSelMarkup"
        Me.btn_showSelMarkup.Size = New System.Drawing.Size(200, 32)
        Me.btn_showSelMarkup.TabIndex = 2
        Me.btn_showSelMarkup.Text = "Show Selected Markup and Comment (In full UI mode)"
        '
        'lb_markup_id_name
        '
        Me.lb_markup_id_name.Enabled = False
        Me.lb_markup_id_name.Location = New System.Drawing.Point(8, 24)
        Me.lb_markup_id_name.Name = "lb_markup_id_name"
        Me.lb_markup_id_name.Size = New System.Drawing.Size(200, 199)
        Me.lb_markup_id_name.TabIndex = 0
        '
        'AxEModelViewControl1
        '
        Me.AxEModelViewControl1.Enabled = True
        Me.AxEModelViewControl1.Location = New System.Drawing.Point(24, 16)
        Me.AxEModelViewControl1.Name = "AxEModelViewControl1"
        Me.AxEModelViewControl1.OcxState = CType(resources.GetObject("AxEModelViewControl1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxEModelViewControl1.Size = New System.Drawing.Size(511, 247)
        Me.AxEModelViewControl1.TabIndex = 57
        '
        'eDrawingsConsole
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(872, 869)
        Me.Controls.Add(Me.AxEModelViewControl1)
        Me.Controls.Add(Me.gb_Markup)
        Me.Controls.Add(Me.lscale)
        Me.Controls.Add(Me.gb_Markup1)
        Me.Controls.Add(Me.gb_Config_sheet)
        Me.Controls.Add(Me.gb_Events)
        Me.Controls.Add(Me.gb_Tooltips)
        Me.Controls.Add(Me.gb_FileOp)
        Me.Controls.Add(Me.gb_view)
        Me.Controls.Add(Me.gb_Components)
        Me.Name = "eDrawingsConsole"
        Me.Text = "eDrawingsConsole 2009"
        Me.gb_view.ResumeLayout(False)
        Me.gb_Components.ResumeLayout(False)
        Me.gb_FileOp.ResumeLayout(False)
        Me.gb_Tooltips.ResumeLayout(False)
        Me.gb_Tooltips.PerformLayout()
        CType(Me.nb_ttX, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nb_ttY, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gb_Events.ResumeLayout(False)
        Me.gb_Config_sheet.ResumeLayout(False)
        Me.gb_Markup1.ResumeLayout(False)
        Me.lscale.ResumeLayout(False)
        Me.gb_Scale.ResumeLayout(False)
        Me.gb_Scale.PerformLayout()
        CType(Me.nb_Scale, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nb_offsetY, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nb_offsetx, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.nb_copies, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gb_orientation.ResumeLayout(False)
        Me.gb_Markup.ResumeLayout(False)
        CType(Me.AxEModelViewControl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region


    '''This variable keeps track of the animation state of the control. See btn_Animate_Click()
    Private m_IsAnimated As Boolean
    '''This variable is the interface to the Markup Control for eDrawings professional.
    Private m_emv As EModelViewMarkup.EModelMarkupControl



    ''Shuts down the application
    Private Sub eDrawingConsole_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        End

    End Sub
    '''Change to a standard Isometric view.
    Private Sub Btn_Iso_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Iso.Click
        AxEModelViewControl1.ViewOrientation = EModelView.EMVViewOrientation.eMVOrientationIsoMetric
    End Sub
    '''Change to a standard Front view.
    Private Sub btn_front_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_front.Click
        AxEModelViewControl1.ViewOrientation = EModelView.EMVViewOrientation.eMVOrientationFront
    End Sub
    '''Change to a standard Left view.
    Private Sub btn_left_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_left.Click
        AxEModelViewControl1.ViewOrientation = EModelView.EMVViewOrientation.eMVOrientationLeft
    End Sub
    '''Change to a standard Top view.
    Private Sub btn_top_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_top.Click
        AxEModelViewControl1.ViewOrientation = EModelView.EMVViewOrientation.eMVOrientationTop
    End Sub
    '''Change back to the original standard view.
    Private Sub btn_Home_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Home.Click
        AxEModelViewControl1.ViewOrientation = EModelView.EMVViewOrientation.eMVOrientationHome
    End Sub
    '''Animate through all standard views.
    Private Sub btn_Animate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Animate.Click
        If (m_IsAnimated = False) Then
            AxEModelViewControl1.Animate(EModelView.EMVAnimateAction.eMVContinuous)
            btn_Animate.Text = "Stop"
            m_IsAnimated = True
        Else
            AxEModelViewControl1.Animate(EModelView.EMVAnimateAction.eMVStop)
            btn_Animate.Text = "Animate"
            m_IsAnimated = False
        End If
    End Sub
    '''Change the currently displayed file via a dialog.
    Private Sub btn_file_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_file.Click
        Me.OpenFileDialog1.ShowDialog()
        Dim sFilename As String
        sFilename = Me.OpenFileDialog1.FileName

        If sFilename <> "" Then
            AxEModelViewControl1.OpenDoc(sFilename, 0, 0, 0, "")  ''Change the active filename
            Me.btn_Animate.Enabled = True
            Me.btn_front.Enabled = True
            Me.btn_top.Enabled = True
            Me.btn_left.Enabled = True
            Me.Btn_Iso.Enabled = True
            Me.btn_SaveAs.Enabled = True
            Me.btn_Print.Enabled = True
            Me.btn_Home.Enabled = True
            Me.btn_Circle.Enabled = True
            Me.btn_rectangle.Enabled = True
            Me.btn_CursorRotate.Enabled = True
            Me.btn_MarkupText.Enabled = True
            Me.btn_ShowConfigOrSheet.Enabled = True

            Me.btn_ShowSelected.Enabled = True
            Me.btn_HideSelected.Enabled = True
            Me.btn_getHidden.Enabled = True

            Me.btn_highlightSelected.Enabled = True
            Me.btn_UnhighlightSelected.Enabled = True
            Me.btn_getHighLight.Enabled = True

            Me.btn_CreateTT.Enabled = True
            Me.btn_ShowSelectedTT.Enabled = True
            Me.btn_HideSelectedTT.Enabled = True
            Me.Btn_EditTT.Enabled = True


            Me.cb_Selection.Enabled = True
            Me.cb_MouseOver.Enabled = True

            Me.cb_perspective.Enabled = True

            Me.tb_tt_title.Enabled = True
            Me.tb_tt_text.Enabled = True
            Me.nb_ttX.Enabled = True
            Me.nb_ttY.Enabled = True
            Me.cb_ShowAtMouse.Enabled = True
            Me.gb_Components.Enabled = True
            Me.gb_Config_sheet.Enabled = True
            Me.gb_Events.Enabled = True

            Me.btn_Print.Enabled = True
            Me.btn_print_and_ps.Enabled = True

            Me.gb_Tooltips.Enabled = True
            Me.btn_SheetSize.Enabled = True
            Me.lb_ToolTips.Enabled = True
            Me.lscale.Enabled = True
            Me.gb_view.Enabled = True

            Me.gb_Markup.Enabled = True
            Me.lb_markup_id_name.Enabled = True

            Me.btn_showSelMarkup.Enabled = True
            Me.gb_Markup1.Enabled = True




        End If
    End Sub
    '''Print using standard the standard EDrawings print dialog.
    Private Sub btn_Print_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Print.Click
        AxEModelViewControl1.Print(True, "")
    End Sub
    ''Save as a supported file type (jpeg, tiff, exe, html, zip)
    Private Sub btn_SaveAs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_SaveAs.Click
        Me.AxEModelViewControl1.Save("", True, "")
    End Sub


    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub

    Private Sub btn_highlightSelected_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_highlightSelected.Click
        AxEModelViewControl1.set_ComponentState(lb_Components.SelectedItem, EModelView.EMVComponentState.eMVHighlight, True)

    End Sub

    Private Sub btn_UnhighlightSelected_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_UnhighlightSelected.Click
        AxEModelViewControl1.set_ComponentState(lb_Components.SelectedItem, EModelView.EMVComponentState.eMVHighlight, False)
    End Sub

    Private Sub btn_HideSelected_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_HideSelected.Click
        AxEModelViewControl1.set_ComponentState(lb_Components.SelectedItem, EModelView.EMVComponentState.eMVHidden, True)
    End Sub

    Private Sub btn_ShowSelected_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_ShowSelected.Click
        AxEModelViewControl1.set_ComponentState(lb_Components.SelectedItem, EModelView.EMVComponentState.eMVHidden, False)
    End Sub

    Private Sub btn_getHighLight_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_getHighLight.Click
        MsgBox(AxEModelViewControl1.get_ComponentState(lb_Components.SelectedItem, EModelView.EMVComponentState.eMVHighlight), MsgBoxStyle.Information, "Highlight State")
    End Sub

    Private Sub btn_getHidden_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_getHidden.Click
        MsgBox(AxEModelViewControl1.get_ComponentState(lb_Components.SelectedItem, EModelView.EMVComponentState.eMVHidden), MsgBoxStyle.Information, "Hidden State")
    End Sub

    Private Sub AxEModelViewControl1_OnComponentMouseOverNotify(ByVal sender As System.Object, ByVal e As AxEModelView._IEModelViewControlEvents_OnComponentMouseOverNotifyEvent)
        If cb_MouseOver.Checked = True Then

            Dim s As String
            Dim cname As String
            cname = e.componentName
            If cname = "" Then
                cname = "None"
            End If

            s = cname & vbNewLine & "X: " & e.xCoordinate & vbNewLine & "Y: " & e.yCoordinate
            MsgBox(s, MsgBoxStyle.Information, "Component Mouse Over")
        End If

    End Sub

    Private Sub AxEModelViewControl1_OnComponentSelectionNotify(ByVal sender As System.Object, ByVal e As AxEModelView._IEModelViewControlEvents_OnComponentSelectionNotifyEvent)
        If cb_Selection.Checked = True Then
            Dim s As String
            Dim cname As String
            cname = e.componentName
            If cname = "" Then
                cname = "None"
            End If

            s = cname & vbNewLine & "X: " & e.xCoordinate & vbNewLine & "Y: " & e.yCoordinate
            MsgBox(s, MsgBoxStyle.Information, "Component Selection")
        End If

    End Sub

    Private Sub d_OnFinishedLoadingDocument()
        ''     MsgBox("Document: " & AxEModelViewControl1.FileName & " has finished loading.")
        btn_ShowConfigOrSheet.Text = ""
        btn_ShowConfigOrSheet.Enabled = False
        lb_sheets_configs.Items.Clear()
        lb_Components.Items.Clear()

        If AxEModelViewControl1.FileName.ToLower.EndsWith("easm") Or AxEModelViewControl1.FileName.ToLower.EndsWith("sldasm") Then
            Me.enableDrawingsUI(False)
            Me.enablePartsUI(True)
            Me.enableAssembliesUI(True)
        End If

        If AxEModelViewControl1.FileName.ToLower.EndsWith("eprt") Or AxEModelViewControl1.FileName.ToLower.EndsWith("sldprt") Then
            Me.enableDrawingsUI(False)
            Me.enableAssembliesUI(False)
            Me.enablePartsUI(True)
        End If

        If AxEModelViewControl1.FileName.ToLower.EndsWith("edrw") Or AxEModelViewControl1.FileName.ToLower.EndsWith("slddrw") Then
            Me.enableAssembliesUI(False)
            Me.enablePartsUI(False)
            Me.enableDrawingsUI(True)
        End If



        If Not m_emv Is Nothing Then


            Me.lb_markup_id_name.Items.Clear()
            Dim i As Long
            For i = 0 To Me.m_emv.CommentCount - 1
                Dim s As String
                s = Me.m_emv.CommentID(i) & " , " & Me.m_emv.CommentName(i)
                Me.lb_markup_id_name.Items.Add(s)

            Next
        End If

    End Sub
    Delegate Sub FinishedLoadingDelegate()

    Private Sub AxEModelViewControl1_OnFinishedLoadingDocument(ByVal sender As Object, ByVal e As AxEModelView._IEModelViewControlEvents_OnFinishedLoadingDocumentEvent)
        Dim ar As System.IAsyncResult
        ar = Me.BeginInvoke(New FinishedLoadingDelegate(AddressOf d_OnFinishedLoadingDocument))
        Me.EndInvoke(ar)
    End Sub
    Private Sub AxEModelViewControl1_OnFailedLoadingDocument(ByVal sender As Object, ByVal e As AxEModelView._IEModelViewControlEvents_OnFailedLoadingDocumentEvent)
        MsgBox("Failed to load: " & e.fileName)

    End Sub

    Private Sub AxEModelViewControl1_OnFailedSavingDocument(ByVal sender As Object, ByVal e As AxEModelView._IEModelViewControlEvents_OnFailedSavingDocumentEvent)
        MsgBox("Failed to save: " & e.fileName)
    End Sub

    Private Sub RefreshComponentList()

        Dim ccount As Integer
        ccount = AxEModelViewControl1.get_ComponentCount("")

        lb_Components.Items.Clear()

        Dim i As Integer
        For i = 0 To ccount - 1
            lb_Components.Items.Add(AxEModelViewControl1.get_ComponentName("", i))
        Next

    End Sub

    Private Sub RefreshConfigurationList()
        lb_sheets_configs.Items.Clear()

        Dim conCount As Integer
        conCount = AxEModelViewControl1.ConfigurationCount

        Dim i As Integer
        For i = 0 To conCount - 1
            lb_sheets_configs.Items.Add(AxEModelViewControl1.get_ConfigurationName(i))
        Next

    End Sub

    Private Sub RefreshSheetList()
        lb_sheets_configs.Items.Clear()

        Dim sheetCount As Integer
        sheetCount = AxEModelViewControl1.SheetCount

        Dim i As Integer
        For i = 0 To sheetCount - 1
            lb_sheets_configs.Items.Add(AxEModelViewControl1.get_SheetName(i))
        Next
    End Sub

    Private Sub cb_perspective_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cb_perspective.CheckedChanged
        AxEModelViewControl1.set_ViewState(EModelView.EMVViewState.eMVPerspective, cb_perspective.Checked)
    End Sub

    Private Sub cb_Explode_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cb_Explode.CheckedChanged
        m_emv.ViewState(EModelViewMarkup.EMVMarkupViewState.eMVMarkupExplode) = cb_Explode.Checked
    End Sub

    Private Sub btn_CreateTT_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_CreateTT.Click
        Dim ttID As Long
        Dim sCount As String
        sCount = AxEModelViewControl1.TooltipCount()
        ttID = AxEModelViewControl1.CreateTooltip("TipTitle: " & sCount, "TipText: " & sCount, False, 0, 0)
        AxEModelViewControl1.ShowTooltip(ttID)
        Dim index As Integer




        index = lb_ToolTips.Items.Add(ttID)
        lb_ToolTips.SetSelected(index, True)

        Me.tb_tt_title.Text = AxEModelViewControl1.get_TipTitle(ttID)
        Me.tb_tt_text.Text = AxEModelViewControl1.get_TipText(ttID)
        Me.nb_ttX.Value = AxEModelViewControl1.get_TipXCoordinate(ttID)
        Me.nb_ttY.Value = AxEModelViewControl1.get_TipYCoordinate(ttID)
        Me.cb_ShowAtMouse.Checked = AxEModelViewControl1.get_ShowTipAtMousePosition(ttID)


    End Sub

    Private Sub Btn_EditTT_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_EditTT.Click
        AxEModelViewControl1.set_TipTitle(lb_ToolTips.SelectedIndex(), Me.tb_tt_title.Text)
        AxEModelViewControl1.set_TipText(lb_ToolTips.SelectedIndex(), Me.tb_tt_text.Text)
        AxEModelViewControl1.set_TipXCoordinate(lb_ToolTips.SelectedIndex(), Me.nb_ttX.Value)
        AxEModelViewControl1.set_TipYCoordinate(lb_ToolTips.SelectedIndex(), Me.nb_ttY.Value)
        AxEModelViewControl1.set_ShowTipAtMousePosition(lb_ToolTips.SelectedIndex(), Me.cb_ShowAtMouse.Checked)
        AxEModelViewControl1.ShowTooltip(lb_ToolTips.SelectedIndex())
    End Sub

    Private Sub lb_ToolTips_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

        Me.tb_tt_title.Text = AxEModelViewControl1.get_TipTitle(lb_ToolTips.SelectedIndex())
        Me.tb_tt_text.Text = AxEModelViewControl1.get_TipText(lb_ToolTips.SelectedIndex())
        Me.nb_ttX.Value = AxEModelViewControl1.get_TipXCoordinate(lb_ToolTips.SelectedIndex())
        Me.nb_ttY.Value = AxEModelViewControl1.get_TipYCoordinate(lb_ToolTips.SelectedIndex())
        Me.cb_ShowAtMouse.Checked = AxEModelViewControl1.get_ShowTipAtMousePosition(lb_ToolTips.SelectedIndex())

    End Sub

    Private Sub btn_HideSelectedTT_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_HideSelectedTT.Click
        AxEModelViewControl1.HideTooltip(lb_ToolTips.SelectedIndex())
    End Sub

    Private Sub btn_ShowSelectedTT_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_ShowSelectedTT.Click
        AxEModelViewControl1.ShowTooltip(lb_ToolTips.SelectedIndex())
    End Sub

    Private Sub btn_ShowConfigOrSheet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_ShowConfigOrSheet.Click


        If AxEModelViewControl1.FileName.ToLower.EndsWith("easm") Or AxEModelViewControl1.FileName.ToLower.EndsWith("sldasm") Or AxEModelViewControl1.FileName.ToLower.EndsWith("eprt") Or AxEModelViewControl1.FileName.ToLower.EndsWith("sldprt") Then
            AxEModelViewControl1.ShowConfiguration(lb_sheets_configs.SelectedIndex())
        End If


        If AxEModelViewControl1.FileName.ToLower.EndsWith("easm") Or AxEModelViewControl1.FileName.ToLower.EndsWith("sldasm") Then
            RefreshComponentList()
        End If

        If AxEModelViewControl1.FileName.ToLower.EndsWith("edrw") Or AxEModelViewControl1.FileName.ToLower.EndsWith("slddrw") Then
            AxEModelViewControl1.ShowSheet(lb_sheets_configs.SelectedIndex())
        End If

    End Sub

    Private Sub btn_rectangle_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_rectangle.Click
        m_emv.ViewOperator = EModelViewMarkup.EMVMarkupOperators.eMVOperatorMarkupRectangle
    End Sub

    Private Sub btn_Circle_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Circle.Click
        m_emv.ViewOperator = EModelViewMarkup.EMVMarkupOperators.eMVOperatorMarkupCircle
    End Sub

    Private Sub btn_MarkupText_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_MarkupText.Click
        m_emv.ViewOperator = EModelViewMarkup.EMVMarkupOperators.eMVOperatorMarkupText
    End Sub

    Private Sub btn_CursorRotate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_CursorRotate.Click
        AxEModelViewControl1.ViewOperator = EModelView.EMVOperators.eMVOperatorRotate
    End Sub

    Private Sub btn_Quit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Quit.Click
        End
    End Sub



    Private Sub btn_showSelMarkup_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_showSelMarkup.Click
        Me.m_emv.ShowComment(Me.m_emv.CommentID(Me.lb_markup_id_name.SelectedIndex))

    End Sub


    Private Sub btn_SheetSize_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_SheetSize.Click
        MsgBox("Sheet Size:  Width: " & AxEModelViewControl1.SheetWidth & " , Height (Length): " & AxEModelViewControl1.SheetHeight)
    End Sub

    Public Sub enableAssembliesUI(ByVal enabled As Boolean)
        Me.gb_Components.Enabled = enabled
        If (enabled) Then
            Me.rb_PrintScreen.Checked = True
        End If

        If (enabled) Then
            If ((Not Me.m_emv Is Nothing)) Then
                If m_emv.CanExplode = True Then
                    Me.cb_Explode.Enabled = True
                Else
                    Me.cb_Explode.Enabled = False
                End If
            Else
                Me.cb_Explode.Enabled = False
            End If

        Else
            Me.cb_Explode.Enabled = False
        End If

        If enabled Then
            RefreshComponentList()
        End If
    End Sub
    Public Sub enablePartsUI(ByVal enabled As Boolean)
        Me.rb_100percent.Enabled = Not enabled  ''turn these off if enabled

        Me.rb_ScaleToFit.Enabled = Not enabled ''turn these off if enabled

        If (enabled) Then
            Me.rb_PrintScreen.Checked = True
        End If

        btn_ShowConfigOrSheet.Enabled = enabled

        If enabled Then
            btn_ShowConfigOrSheet.Text = "Show Configuration"
        End If

        If enabled Then
            RefreshConfigurationList()
        End If


    End Sub
    Public Sub enableDrawingsUI(ByVal enabled As Boolean)


        btn_ShowConfigOrSheet.Enabled = enabled

        If enabled Then
            btn_ShowConfigOrSheet.Text = "Show Sheet"
        End If

        Me.btn_SheetSize.Enabled = enabled

        Me.rb_100percent.Enabled = enabled   ''turn these on if enabled
        Me.rb_ScaleToFit.Enabled = enabled ''turn these on if enabled
        If enabled Then
            RefreshSheetList()
        End If
    End Sub



    Public Sub enableMarkupUI(ByVal enabled As Boolean)
        Me.Text = Me.Text + ", Markup enabled=" + enabled.ToString()
        Me.cb_Explode.Enabled = enabled
        Me.btn_Circle.Enabled = enabled
        Me.btn_rectangle.Enabled = enabled
        Me.btn_MarkupText.Enabled = enabled
        Me.btn_showSelMarkup.Enabled = enabled
        Me.lb_markup_id_name.Enabled = enabled
    End Sub



    Private Sub btn_print_and_ps_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_print_and_ps.Click

        System.Diagnostics.Debug.WriteLine("E : " & PaperKind.ESheet)
        System.Diagnostics.Debug.WriteLine("D : " & PaperKind.DSheet)
        System.Diagnostics.Debug.WriteLine("C : " & PaperKind.CSheet)
        System.Diagnostics.Debug.WriteLine("B4 : " & PaperKind.B4)
        System.Diagnostics.Debug.WriteLine("A3 : " & PaperKind.A3)

        System.Diagnostics.Debug.WriteLine("Letter : " & PaperKind.Letter)
        System.Diagnostics.Debug.WriteLine("Automatic Paper feed: " & Printing.PaperSourceKind.AutomaticFeed)


        Dim color As Long = 0
        Dim draft As Long = 0
        Dim shaded As Long = 0
        Dim orientation As Long = 1
        Dim printType As Long
        Dim copies As Long
        Dim offsetX As Long
        Dim offsetY As Long

        Dim scaleD As Double
        scaleD = Me.nb_Scale.Value

        offsetX = Me.nb_offsetx.Value
        offsetY = Me.nb_offsetY.Value


        If Me.rb_100percent.Checked = True Then
            printType = EModelView.EMVPrintType.eOneToOne
        ElseIf Me.rb_PrintScreen.Checked = True Then
            printType = EModelView.EMVPrintType.eWYSIWYG
        ElseIf Me.rb_ScaleBy.Checked = True Then
            printType = EModelView.EMVPrintType.eScaled
        ElseIf Me.rb_Selection.Checked = True Then
            printType = EModelView.EMVPrintType.ePrintSelection
        Else
            printType = EModelView.EMVPrintType.eScaleToFit
        End If



        copies = Me.nb_copies.Value

        If Me.cb_color.Checked = True Then
            color = 1
        End If

        If Me.cb_Draft.Checked = True Then
            draft = 1
        End If

        If Me.cb_Shaded.Checked = True Then
            shaded = 1
        End If

        If Me.rb_landscape.Checked = True Then
            orientation = 2
        End If
        Dim paperSize2 As Integer
        paperSize2 = Me.cb_PaperSizex.SelectedItem
        AxEModelViewControl1.SetPageSetupOptions(orientation, paperSize2, 0, 0, copies, 7, Me.cb_Printers.SelectedItem, 1, 1, 1, 1)
        AxEModelViewControl1.Print3(False, Me.tb_docName.Text, shaded, draft, color, printType, scaleD, offsetX, offsetY)

    End Sub




    Private Sub btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Close.Click
        AxEModelViewControl1.CloseActiveDoc("")
    End Sub


    Private Sub AxEModelViewControl1_OnFailedPrintingDocument(ByVal sender As Object, ByVal e As AxEModelView._IEModelViewControlEvents_OnFailedPrintingDocumentEvent)
        MsgBox("Printing " & e.printJobName & " failed.")
    End Sub

    Private Sub AxEModelViewControl1_OnFinishedPrintingDocument(ByVal sender As Object, ByVal e As AxEModelView._IEModelViewControlEvents_OnFinishedPrintingDocumentEvent)
        MsgBox(e.printJobName & " was sent to the print queue.")
    End Sub

    Private Sub eDrawingsConsole_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        m_emv = AxEModelViewControl1.CoCreateInstance("EModelViewMarkup.EModelMarkupControl")
        If Not m_emv Is Nothing Then
            m_emv.EnableFeatures = 0
            Me.enableMarkupUI(True)
        Else
            Me.enableMarkupUI(False)
        End If


        Me.cb_PaperSizex.Items.Add(PaperKind.A2)
        Me.cb_PaperSizex.Items.Add(PaperKind.A3)
        Me.cb_PaperSizex.Items.Add(PaperKind.A4)
        Me.cb_PaperSizex.Items.Add(PaperKind.A5)
        Me.cb_PaperSizex.Items.Add(PaperKind.B4)
        Me.cb_PaperSizex.Items.Add(PaperKind.B5)
        Me.cb_PaperSizex.Items.Add(PaperKind.CSheet)
        Me.cb_PaperSizex.Items.Add(PaperKind.DSheet)
        Me.cb_PaperSizex.Items.Add(PaperKind.ESheet)

        Dim sPrinter As String
        For Each sPrinter In System.Drawing.Printing.PrinterSettings.InstalledPrinters
            Me.cb_Printers.Items.Add(sPrinter)
        Next

        Dim currentPrinter As New System.Drawing.Printing.PrinterSettings
        Dim currentPrinterName As String = ""

        If Not currentPrinter Is Nothing Then
            currentPrinterName = currentPrinter.PrinterName
        End If


        If cb_Printers.Items.Count > 0 Then
            cb_Printers.SelectedIndex = 0
            cb_Printers.SelectedItem = currentPrinterName

        End If

        Me.cb_PaperSizex.SelectedIndex = 2
        Me.nb_Scale.Value = 1
    End Sub


    Private Sub cb_PaperSizex_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cb_PaperSizex.SelectedIndexChanged
        Me.lbl_PaperInfo.Text = PaperInfoFromEnum(cb_PaperSizex.SelectedItem())
    End Sub
    Private Function PaperInfoFromEnum(ByVal paperEnum As PaperKind) As String
        Dim format1 As String
        Dim format1i As Integer
        Dim format2 As String
        format1i = paperEnum

        format1 = format1i.ToString()


        If paperEnum = PaperKind.A2 Then
            format2 = "(420 mm x 594 mm), (16.53 in x 23.39in)"
        ElseIf paperEnum = PaperKind.A3 Then
            format2 = "(297 mm by 420 mm), (11.69 in x 16.53 in)"
        ElseIf paperEnum = PaperKind.A4 Then
            format2 = "(210 mm by 297 mm), (8.27 x 11.69 in)"
        ElseIf paperEnum = PaperKind.B4 Then
            format2 = "(250 mm by 353 mm), (9.84 in x 13.90 in)"
        ElseIf paperEnum = PaperKind.B5 Then
            format2 = "(176 mm by 250 mm), (6.9 in x 9.84 in)"
        ElseIf paperEnum = PaperKind.CSheet Then
            format2 = "(17 in. by 22 in.)"
        ElseIf paperEnum = PaperKind.DSheet Then
            format2 = "(22 in. by 34 in.)"
        ElseIf paperEnum = PaperKind.ESheet Then
            format2 = "(34 in. by 44 in.)"
        Else
            format2 = "unknown"

        End If

        PaperInfoFromEnum = "Selected printer constant enum: " + format1 + ", Dimensions: " + format2
    End Function

    Private Sub cb_MouseOver_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cb_MouseOver.CheckedChanged
        If Me.cb_MouseOver.Checked = True Then
            Me.AxEModelViewControl1.ViewOperator = EModelView.EMVOperators.eMVOperatorSelect
        End If
    End Sub

    Private Sub cb_Selection_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cb_Selection.CheckedChanged
        If Me.cb_Selection.Checked = True Then
            Me.AxEModelViewControl1.ViewOperator = EModelView.EMVOperators.eMVOperatorSelect
        End If
    End Sub

    Private Sub nb_offsetx_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles nb_offsetx.ValueChanged

    End Sub



End Class

