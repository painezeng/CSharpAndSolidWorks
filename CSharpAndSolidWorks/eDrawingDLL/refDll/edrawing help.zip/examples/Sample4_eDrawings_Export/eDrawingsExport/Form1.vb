Imports SldWorks = SolidWorks.Interop.sldworks
Imports SwConst = SolidWorks.Interop.swconst

Public Class edwExport
    Inherits System.Windows.Forms.Form
    Public swFilenameIn As String
    Public edwExportFilenameOut As String
    Friend WithEvents AxEModelViewControl1 As AxEModelView.AxEModelViewControl
    Public swApp As SldWorks.SldWorks

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    'Friend WithEvents AxEModelViewControl1 As AxEModelView.AxEModelViewControl
    ' Friend WithEvents AxEModelViewControl2 As AxEModelView.AxEModelViewControl
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(edwExport))
        Me.AxEModelViewControl1 = New AxEModelView.AxEModelViewControl
        CType(Me.AxEModelViewControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'AxEModelViewControl1
        '
        Me.AxEModelViewControl1.Enabled = True
        Me.AxEModelViewControl1.Location = New System.Drawing.Point(33, 36)
        Me.AxEModelViewControl1.Name = "AxEModelViewControl1"
        Me.AxEModelViewControl1.OcxState = CType(resources.GetObject("AxEModelViewControl1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxEModelViewControl1.Size = New System.Drawing.Size(209, 203)
        Me.AxEModelViewControl1.TabIndex = 0
        '
        'edwExport
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(281, 282)
        Me.Controls.Add(Me.AxEModelViewControl1)
        Me.Name = "edwExport"
        Me.Text = "eDrawings Export"
        CType(Me.AxEModelViewControl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region


    Private Sub edwExport_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim args() As [String] = Environment.GetCommandLineArgs()
        swFilenameIn = args(1)
        edwExportFilenameOut = args(2)

        swApp = New SldWorks.SldWorks
        Dim ee As Integer
        Dim ww As Integer

        Dim swFilenameArray() As String
        swFilenameArray = swFilenameIn.Split(".")

        Dim ftype As Integer
        Dim eExtOut As String

        If swFilenameArray(1).ToLower = "sldprt" Then
            ftype = SwConst.swDocumentTypes_e.swDocPART
            eExtOut = "eprt"
        ElseIf swFilenameArray(1).ToLower = "sldasm" Then
            ftype = SwConst.swDocumentTypes_e.swDocASSEMBLY
            eExtOut = "easm"
        Else
            ftype = SwConst.swDocumentTypes_e.swDocDRAWING
            eExtOut = "edrw"
        End If

        Dim eDrawingFileName As String
        eDrawingFileName = swFilenameArray(0) & "." & eExtOut
        Dim swModel As SldWorks.ModelDoc2

        '''Open the document in SolidWorks

        swModel = swApp.OpenDoc6(swFilenameIn, ftype, SwConst.swOpenDocOptions_e.swOpenDocOptions_Silent, "", ee, ww)

        '''Publish the eDrawing with the appropriate eDrawing filename extension.
        swModel.SaveAs4(eDrawingFileName, 0, SwConst.swSaveAsOptions_e.swSaveAsOptions_Silent, ee, ww)
        swApp.QuitDoc(swFilenameIn)
        swApp.ExitApp()
        swApp = Nothing

        Me.Show()

        '''Open the newly published eDrawing in the eDrawings control.
        Me.AxEModelViewControl1.OpenDoc(eDrawingFileName, False, False, True, "")

    End Sub

    Private Sub AxEModelViewControl1_OnFinishedLoadingDocument(ByVal sender As Object, ByVal e As AxEModelView._IEModelViewControlEvents_OnFinishedLoadingDocumentEvent)
        '''Wait until the document is finished loading before you try to save
        Me.AxEModelViewControl1.Save(edwExportFilenameOut, False, "")
    End Sub



    Private Sub AxEModelViewControl1_OnFinishedSavingDocument(ByVal sender As Object, ByVal e As System.EventArgs)
        ''Only exit when the file is finished saving.
        End

    End Sub
End Class



